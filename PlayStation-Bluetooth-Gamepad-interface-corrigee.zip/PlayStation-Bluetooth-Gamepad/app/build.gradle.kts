plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.azgad.playstationgamepad"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.azgad.playstationgamepad"
        minSdk = 28
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
