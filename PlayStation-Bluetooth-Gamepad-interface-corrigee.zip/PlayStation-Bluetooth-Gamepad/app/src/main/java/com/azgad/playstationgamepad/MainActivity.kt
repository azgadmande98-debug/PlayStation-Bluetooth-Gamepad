package com.azgad.playstationgamepad

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var hid: BluetoothHidDevice? = null
    private var connected: BluetoothDevice? = null
    private var adapter: BluetoothAdapter? = null
    private var registered = false

    // Gamepad report: 16 buttons, 4-bit hat, X/Y/Rx/Ry and two triggers.
    private val descriptor = byteArrayOf(
        0x05,0x01, 0x09,0x05, 0xA1.toByte(),0x01,
        0x15,0x00, 0x25,0x01, 0x35,0x00, 0x45,0x01,
        0x75,0x01, 0x95,0x10, 0x05,0x09, 0x19,0x01, 0x29,0x10, 0x81.toByte(),0x02,
        0x05,0x01, 0x15,0x00, 0x25,0x07, 0x35,0x00, 0x46,0x3B,0x01,
        0x75,0x04, 0x95,0x01, 0x09,0x39, 0x81.toByte(),0x42,
        0x05,0x01, 0x15,0x00, 0x26,0xFF.toByte(),0x00, 0x09,0x30, 0x09,0x31,
        0x09,0x33, 0x09,0x34, 0x75,0x08, 0x95,0x04, 0x81.toByte(),0x02,
        0x09,0x32, 0x09,0x35, 0x15,0x00, 0x26,0xFF.toByte(),0x00,
        0x75,0x08, 0x95,0x02, 0x81.toByte(),0x02, 0xC0.toByte()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.decorView.systemUiVisibility =
            (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/gamepad.html")
        adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) notifyJs("Bluetooth indisponible sur ce téléphone")
        else requestBtPermission()
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 41)
        } else startHidProfile()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 41 && results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) startHidProfile()
        else notifyJs("Autorisation Bluetooth refusée")
    }

    private fun startHidProfile() {
        try {
            adapter?.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                    if (profile != BluetoothProfile.HID_DEVICE) return
                    hid = proxy as BluetoothHidDevice
                    val sdp = BluetoothHidDeviceAppSdpSettings(
                        "PS Bluetooth Gamepad", "PPSSPP PlayStation Controller", "AZGAD MANDE",
                        BluetoothHidDevice.SUBCLASS1_GAMEPAD, descriptor
                    )
                    val ok = hid?.registerApp(sdp, null, null, executor, object : BluetoothHidDevice.Callback() {
                        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registeredNow: Boolean) {
                            registered = registeredNow
                            notifyJs(if (registeredNow) "Manette prête — recherche TV" else "Service Bluetooth arrêté")
                            if (registeredNow) makeDiscoverable()
                        }
                        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
                            if (state == BluetoothProfile.STATE_CONNECTED) {
                                connected = device
                                notifyJs("Connecté : " + (device.name ?: "Android TV"))
                            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                                connected = null
                                notifyJs("Déconnecté")
                            }
                        }
                    })
                    if (ok != true) notifyJs("Échec d'enregistrement HID. Ce téléphone peut ne pas prendre en charge le mode manette Bluetooth.")
                }
                override fun onServiceDisconnected(profile: Int) {
                    hid = null; registered = false; connected = null
                    notifyJs("Service Bluetooth déconnecté")
                }
            }, BluetoothProfile.HID_DEVICE)
        } catch (e: Exception) {
            notifyJs("HID non disponible : " + (e.message ?: "erreur Bluetooth"))
        }
    }

    private fun makeDiscoverable() {
        try {
            val intent = android.content.Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
            startActivity(intent)
        } catch (_: Exception) { notifyJs("Active la visibilité Bluetooth dans les réglages Android") }
    }

    private fun notifyJs(message: String) {
        main.post {
            if (::web.isInitialized) web.evaluateJavascript("window.setBluetoothStatus(${org.json.JSONObject.quote(message)})", null)
        }
    }

    private fun sendReport(buttons: Int, hat: Int, x: Int, y: Int, rx: Int, ry: Int, l2: Int, r2: Int) {
        val device = connected ?: return
        val service = hid ?: return
        // 9 bytes: 2 button bytes, hat nibble, 4 axes, 2 trigger bytes.
        val report = byteArrayOf(
            (buttons and 0xFF).toByte(), ((buttons shr 8) and 0xFF).toByte(),
            (hat and 0x0F).toByte(), x.toByte(), y.toByte(), rx.toByte(), ry.toByte(),
            l2.toByte(), r2.toByte()
        )
        try { service.sendReport(device, 1, report) } catch (_: Exception) {}
    }

    inner class Bridge {
        @JavascriptInterface fun send(buttons: Int, hat: Int, x: Int, y: Int, rx: Int, ry: Int, l2: Int, r2: Int) {
            sendReport(buttons, hat, x, y, rx, ry, l2, r2)
        }
        @JavascriptInterface fun connect() {
            main.post {
                if (!registered) { notifyJs("Patiente pendant l'initialisation Bluetooth"); return@post }
                makeDiscoverable()
                notifyJs("Manette visible. Sur la TV, ouvre les réglages Bluetooth et sélectionne PS Bluetooth Gamepad.")
            }
        }
        @JavascriptInterface fun disconnect() {
            try { connected?.let { hid?.disconnect(it) } } catch (_: Exception) {}
        }
        @JavascriptInterface fun status(): String = if (connected != null) "Connecté" else if (registered) "Prête — associe-la à la TV" else "Bluetooth en initialisation"
    }

    override fun onDestroy() {
        try { hid?.unregisterApp(); adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) {}
        super.onDestroy()
    }
}
