# PPSSPP PlayStation Controller — interface révisée

Application Android native Kotlin avec écran de manette PlayStation en mode paysage uniquement.

L'interface a été réorganisée pour se rapprocher de l'image de référence : statut Bluetooth à gauche, titre au centre, commandes en haut, croix directionnelle à gauche, boutons △ □ ○ × à droite, deux joysticks en bas, SELECT/START au centre et rappel du mode paysage.

Dans ⚙ :
- activer le mode édition ;
- faire glisser les commandes pour les repositionner ;
- sélectionner une commande et régler sa taille ;
- enregistrer la disposition, conservée localement ;
- réinitialiser la disposition.

## Compilation
Déposer les fichiers du projet dans le dépôt GitHub, puis ouvrir Actions et lancer le workflow **Build Android APK**. Télécharger l'artefact produit.

## Limite de compatibilité
Le projet utilise le profil Android Bluetooth HID Device. Tous les téléphones Android ne prennent pas en charge cette fonction. L'association à la TV et le test avec PPSSPP sont indispensables. Le nom affiché ne garantit pas à lui seul que PPSSPP distingue deux manettes.
